
package blockchainauction;

/**
 *
 * Não faz nada, apenas class Main.
 * 
 */
public class BlockchainAuction {

    /** 
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
